<?php 
require "db.php";
/*
Modes:

"r" - read only
'a" - read, append content
"w" - read, overwrite
"r+" "w+" 

Functions:

fopen() - open file
fread() - read a file
fgets() -  read a single line
fwrite() - write a content to a file
fclose() - closes opened file
file_exists()  - check if file exists
filesize() - get the size of the file
unlink()  - deletes a file
move_uploaded_file  - moves uploaded file
*/



//fopen(), fread()
// $file = fopen("sample.txt", "r");

// $content = fread($file, filesize("sample.txt"));

// echo $content;


//fgets()
// while (($line = fgets($file)) !== false) {
//     echo $line. "<br>";
// }

//fwrite()
// $file = fopen("sample.txt", "w"); //change to "w"  
// $write = fwrite($file, "never gonna make you cry, never gonna say goodbye
// never gonna tell a lie and hurt you");

// // fwrite($file, "67");


// fclose($file);

$statement = $pdo->query("SELECT file_name, file_path, uploaded_at FROM uploads");


// $display = $statement->fetchAll();

// $file = fopen($display['file_name'], "r");

// $content = fread($file, filesize($display['file_path']));

// echo $content;




?>

<html>
    <head></head>
    <body style="text-align: center;">
        <h2>File Handling</h2>
        <br>
        

        <form method="POST" action="upload.php" enctype="multipart/form-data">
                <input type="file" name="fileUpload" accept="image/*">
                <button type="submit" name="submit_btn">Submit</button>
        </form>

        <br>
        <br>

        <table style="margin-left: auto; margin-right: auto; width: 80%; text-align: center;" border=1>
            
            <tr>
                <th>Image</th>
                <th>File Name</th>
                <th>Uploaded At</th>
            </tr>
            <?php while($row = $statement->fetch()): ?>
            <tr>
                <td><img style="width: 100px; height: auto;" src="<?= $row['file_path']?>" alt=""></td>
                <td><?= $row['file_name']?></td>
                <td><?= $row['uploaded_at']?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </body>
</html>



