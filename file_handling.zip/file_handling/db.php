<?php

$host="localhost";
$username="root";
$password="";
$dbname="filehandling_php";


$dsn = "mysql:host=localhost;dbname=filehandling_php;charset=utf8mb4";

try {
$pdo = new PDO($dsn, "$username", "", [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC
]);
// echo "Success";
}
catch (PDOException $e) {
    echo "connection Failed!" . $e->getMessage();
}

// if ($pdo->connect_error) {
//     echo "Connection Failed!";
// }
// else {
//     echo "Connection Success!";
// }

?>