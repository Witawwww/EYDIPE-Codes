<?php
require "db.php";

$uploadDir = __DIR__ . DIRECTORY_SEPARATOR . "uploads" . DIRECTORY_SEPARATOR;

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    if (!isset($_FILES['fileUpload'])){
        die("Error!");
    }
}

$file = $_FILES['fileUpload'];

// var_dump($file);
$fileName = basename($file['name']);
$tmpName = $file['tmp_name'];

$destination = $uploadDir . $fileName;

if(move_uploaded_file($tmpName, $destination)) {

    $statement = $pdo->prepare("INSERT INTO uploads (file_name, file_path) VALUES (:name, :path)");

    $statement->execute([
        ':name' => $fileName,
        ':path' => 'uploads/' . $fileName
    ]);

    echo "File Uploaded Succesfully!";

    header("Location: index.php");
    exit();

}

?>